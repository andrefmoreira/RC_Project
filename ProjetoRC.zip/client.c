/**********************************************************************
 * CLIENTE liga ao servidor (definido em argv[1]) no porto especificado
 * (em argv[2]), escrevendo a palavra predefinida (em argv[3]).
 * USO: >cliente <enderecoServidor>  <porto>  <Palavra>
 **********************************************************************/
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <pthread.h>
#include <stdbool.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
pthread_t threads[2];
pthread_t thread_read;
pthread_mutex_t mutex_read = PTHREAD_MUTEX_INITIALIZER;
struct sockaddr_in addr1, addr2;
int sock1, sock2;
char multicastAddr1[128];
char multicastAddr2[128];
bool ligado = false;

void erro(char *msg);
void *feed_atualizacao();
void terminal_operacoes(int fd);
int subscrever_cotacao(int fd);
void comprar_acao(int compra_fd);
void vender_acao(int venda_fd);
void read_server(char *string, int fd_read);

int main(int argc, char *argv[])
{
    // socket tcp
    char endServer[100];
    int fd;
    struct sockaddr_in addr;
    struct hostent *hostPtr;

    if (argc != 3)
    {
        printf("cliente <host> <port>\n");
        exit(-1);
    }

    strcpy(endServer, argv[1]);
    if ((hostPtr = gethostbyname(endServer)) == 0)
        erro("Não consegui obter endereço");

    bzero((void *)&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = ((struct in_addr *)(hostPtr->h_addr))->s_addr;
    addr.sin_port = htons((short)atoi(argv[2]));

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        erro("socket");

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
        erro("Connect");

    char buffer[BUF_SIZE];
    int nread = read(fd, buffer, BUF_SIZE - 1);
    buffer[nread] = '\0';
    printf("%s", buffer); // Insere nome

    char nome[30];
    scanf("%s", nome);
    write(fd, nome, sizeof(nome) + 1);

    nread = read(fd, buffer, BUF_SIZE - 1);
    buffer[nread] = '\0';
    printf("%s", buffer);

    scanf("%s", nome);
    write(fd, nome, sizeof(nome) + 1);

    terminal_operacoes(fd);

    close(fd);
    exit(0);
}

void erro(char *msg)
{
    printf("Erro: %s\n", msg);
    exit(-1);
}

void terminal_operacoes(int fd)
{
    char buffer[BUF_SIZE];
    int nread;
    int escolha = 0;
    int verifica_valor = 0;
    int auxthread = 0;
    nread = read(fd, buffer, BUF_SIZE - 1);
    buffer[nread] = '\0';
    printf("%s", buffer);
    while (1)
    {
		nread = read(fd, buffer, BUF_SIZE - 1);
        buffer[nread] = '\0';
        printf("%s", buffer);
        while (verifica_valor == 0)
        {
            fflush(stdin);
            if (scanf("%d", &escolha) == 0)
            {
                printf("Numero inserido nao e valido\n");
            }
            else
            {
                printf("%d ESCOLHA\n", escolha);
                if (escolha <= 5 && escolha > 0)
                {
                    verifica_valor = 1;
                    sprintf(buffer, "%d", escolha);
                    write(fd, buffer, strlen(buffer));
                    printf("%s\n",buffer);
                }
                else
                {
                    printf("Numero inserido nao e valido\n");
                }
            }
        }

        verifica_valor = 0;

        switch (escolha)
        {
        case (1):
            auxthread = subscrever_cotacao(fd); // vai dar print a opcoes que pergunta qual dos mercados e que ele quer subscrever a cotacao
            write(fd, "podes ir mano", 30);
            nread = read(fd, buffer, BUF_SIZE);
            buffer[nread] = '\0';
            if (auxthread == 1)
            {
                if (strcmp(buffer, "sim") == 0)
                {
                    pthread_create(&threads[0], NULL, feed_atualizacao, &auxthread);
                }
                else
                {
                    printf("Já estava subscrito a essa cotacao de mercado\n");
                }
            }
            if (auxthread == 2)
            {
                if (strcmp(buffer, "sim") == 0)
                {
                    pthread_create(&threads[1], NULL, feed_atualizacao, &auxthread);
                }
                else
                {
                    printf("Já estava subscrito a essa cotacao de mercado\n");
                }
            }
            break;

        case (2):
            comprar_acao(fd);
            break;

        case (3):
            vender_acao(fd);
            break;

        case (4):
            if (ligado == true)
            {
                ligado = false;
            }
            else
            {
                ligado = true;
            }
            break;
        case (5):

            nread = read(fd, buffer, BUF_SIZE - 1);
            buffer[nread] = '\0';
            printf("%s", buffer);

            write(fd, buffer, strlen(buffer));
            break;

            // ler prints do saldo e carteira
        }
    }
}

void *feed_atualizacao(void *x)
{
    char buff[BUF_SIZE];
    int id = *((int *)x);

    // socket multicast
    int addrlen1, addrlen2, cnt;
    struct ip_mreq mreq1, mreq2;
    /* set up socket */
    sock1 = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock1 < 0)
    {
        perror("socket");
        exit(1);
    }
    int reuseaddr = 1;
    if (setsockopt(sock1, SOL_SOCKET, SO_REUSEADDR, (void *)&reuseaddr, sizeof(reuseaddr)) < 0)
    {
        perror("socketopt");
        exit(1);
    }

    bzero((char *)&addr1, sizeof(addr1));
    addr1.sin_family = AF_INET;
    addr1.sin_addr.s_addr = htonl(INADDR_ANY);
    addr1.sin_port = htons(6000);
    addrlen1 = sizeof(addr1);

    sock2 = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock2 < 0)
    {
        perror("socket");
        exit(1);
    }
    if (setsockopt(sock2, SOL_SOCKET, SO_REUSEADDR, (void *)&reuseaddr, sizeof(reuseaddr)) < 0)
    {
        perror("socketopt");
        exit(1);
    }
    bzero((char *)&addr2, sizeof(addr2));
    addr2.sin_family = AF_INET;
    addr2.sin_addr.s_addr = htonl(INADDR_ANY);
    addr2.sin_port = htons(6000);
    addrlen2 = sizeof(addr2);
    if (id == 1)
    {
        if (bind(sock1, (struct sockaddr *)&addr1, sizeof(addr1)) < 0)
        {
            perror("bind");
            exit(1);
        }
        mreq1.imr_multiaddr.s_addr = inet_addr(multicastAddr1);
        mreq1.imr_interface.s_addr = htonl(INADDR_ANY);
        if (setsockopt(sock1, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq1, sizeof(mreq1)) < 0)
        {
            perror("setsockopt mreq1");
            exit(1);
        }
        while (1)
        {
            cnt = recvfrom(sock1, buff, sizeof(buff), 0, (struct sockaddr *)&addr1, (socklen_t *)&addrlen1);
            if (cnt < 0)
            {
                perror("recvfrom");
                exit(1);
            }
            else if (cnt == 0)
            {
                break;
            }
            if (ligado == true)
                printf("%s\n", buff);
        }
    }
    if (id == 2)
    {
        if (bind(sock2, (struct sockaddr *)&addr2, sizeof(addr2)) < 0)
        {
            perror("bind");
            exit(1);
        }
        mreq2.imr_multiaddr.s_addr = inet_addr(multicastAddr2);
        mreq2.imr_interface.s_addr = htonl(INADDR_ANY);
        if (setsockopt(sock2, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq2, sizeof(mreq2)) < 0)
        {
            perror("setsockopt mreq2");
            exit(1);
        }
        while (1)
        {
            cnt = recvfrom(sock2, buff, sizeof(buff), 0, (struct sockaddr *)&addr2, (socklen_t *)&addrlen2);
            if (cnt < 0)
            {
                perror("recvfrom");
                exit(1);
            }
            else if (cnt == 0)
            {
                break;
            }
            if (ligado == true)
                printf("%s\n", buff);
        }
    }

    pthread_exit(NULL);
    return NULL;
}

void comprar_acao(int fd_compra)
{

    char buffer_compra[BUF_SIZE];
    char escolha_compra[128];
    char string[1024];

    int nread_compra = read(fd_compra, buffer_compra, BUF_SIZE - 1);
    buffer_compra[nread_compra] = '\0';
    printf("%s", buffer_compra);

    scanf("%s", escolha_compra);
    write(fd_compra, escolha_compra, strlen(escolha_compra));

    nread_compra = read(fd_compra, buffer_compra, BUF_SIZE - 1);
    buffer_compra[nread_compra] = '\0';
    printf("%s", buffer_compra);

    scanf("%s", escolha_compra);
    write(fd_compra, escolha_compra, strlen(escolha_compra));

    nread_compra = read(fd_compra, buffer_compra, BUF_SIZE - 1);
    buffer_compra[nread_compra] = '\0';
    printf("%s", buffer_compra);

    int c;
    while ((c = fgetc(stdin)) != EOF && c != '\n')
        ;

    scanf("%1023[^\n]", string);

    write(fd_compra, string, strlen(string));

    nread_compra = read(fd_compra, buffer_compra, BUF_SIZE - 1);
    buffer_compra[nread_compra] = '\0';
    printf("%s", buffer_compra);

    write(fd_compra, escolha_compra, strlen(escolha_compra));
}

void vender_acao(int fd_compra)
{

    char buffer_venda[BUF_SIZE];
    char escolha_venda[128];
    char string[512];

    // qual acao queremos vender.
    int nread_compra = read(fd_compra, buffer_venda, BUF_SIZE - 1);
    buffer_venda[nread_compra] = '\0';
    printf("%s", buffer_venda);

    scanf("%s", escolha_venda);
    write(fd_compra, escolha_venda, strlen(escolha_venda));

    // fornecer identificacao quantiade e preco
    nread_compra = read(fd_compra, buffer_venda, BUF_SIZE - 1);
    buffer_venda[nread_compra] = '\0';
    printf("%s", buffer_venda);

    int c;
    while ((c = fgetc(stdin)) != EOF && c != '\n')
        ;

    scanf("%1023[^\n]", string);

    write(fd_compra, string, strlen(string));

    nread_compra = read(fd_compra, buffer_venda, BUF_SIZE - 1);
    buffer_venda[nread_compra] = '\0';
    printf("%s", buffer_venda);

    write(fd_compra, string, strlen(string));
}

int subscrever_cotacao(int fd)
{
    char buffer[BUF_SIZE];
    int nread = read(fd, buffer, BUF_SIZE - 1);
    buffer[nread] = '\0';
    printf("%s", buffer);

    char escolha[128];
    scanf("%s", escolha);
    write(fd, escolha, strlen(escolha));

    nread = read(fd, buffer, BUF_SIZE - 1);
    buffer[nread] = '\0';
    int aux = atoi(escolha);

    if (aux == 1)
    {
        strcpy(multicastAddr1, buffer);
    }
    if (aux == 2)
    {
        strcpy(multicastAddr2, buffer);
    }
    write(fd, escolha, strlen(escolha));
    return aux;
}
